﻿========================================================================
    动态链接库：Disable_the_Accessibility_Shortcut_Keys 项目概述
========================================================================

应用程序向导已为您创建了此 Disable_the_Accessibility_Shortcut_Keys DLL。

本文件概要介绍组成 Disable_the_Accessibility_Shortcut_Keys 应用程序的每个文件的内容。


Disable_the_Accessibility_Shortcut_Keys.vcxproj
    这是使用应用程序向导生成的 VC++ 项目的主项目文件，
    其中包含生成该文件的 Visual C++ 
    的版本信息，以及有关使用应用程序向导选择的平台、配置和项目功能的信息。

Disable_the_Accessibility_Shortcut_Keys.vcxproj.filters
    这是使用“应用程序向导”生成的 VC++ 项目筛选器文件。 
    它包含有关项目文件与筛选器之间的关联信息。 在 IDE 
    中，通过这种关联，在特定节点下以分组形式显示具有相似扩展名的文件。
    例如，“.cpp”文件与“源文件”筛选器关联。

Disable_the_Accessibility_Shortcut_Keys.cpp
    这是主 DLL 源文件。

/////////////////////////////////////////////////////////////////////////////
其他标准文件：

StdAfx.h，StdAfx.cpp
    这些文件用于生成名为 Disable_the_Accessibility_Shortcut_Keys.pch 的预编译头 (PCH) 文件和
    名为 StdAfx.obj 的预编译类型文件。

/////////////////////////////////////////////////////////////////////////////
其他注释：

应用程序向导使用“TODO:”注释来指示应添加或自定义的源代码部分。

/////////////////////////////////////////////////////////////////////////////
